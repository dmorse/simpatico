#ifndef DPD_PAIR_H
#define DPD_PAIR_H

/*
* Simpatico - Simulation Package for Polymeric and Molecular Liquids
*
* Copyright 2010, David Morse (morse@cems.umn.edu)
* Distributed under the terms of the GNU General Public License.
*/

#include <util/param/ParamComposite.h>
#include <util/global.h>

#include <math.h>

namespace Inter
{

   using namespace Util;

   /**
   * The soft potential introduced in DPD simulations of Groot et al. 
   *
   * Member functions evaluate energy and force for an individual pair 
   * of nonbonded interacting particles.
   * 
   * \ingroup Inter_Pair_Module
   */
   class DpdPair : public ParamComposite 
   {
   
   public:
   
      /**
      * Constructor.
      */
      DpdPair();

      /**
      * Copy constructor.
      */
      DpdPair(const DpdPair& other);

      /**
      * Assignment.
      */
      DpdPair& operator = (const DpdPair& other);

      /// \name Mutators
      //@{ 

      /**
      * Read epsilon and sigma, initialize other variables.
      *
      * \pre nAtomType must be set, by calling setNAtomType().
      *
      * \param in  input stream 
      */
      void readParam(std::istream &in);

      /**  
      * Set nAtomType value.
      *
      * \param nAtomType number of atom types.
      */
      void setNAtomType(int nAtomType);

      /**
      * Set LJ interaction energy for a specific pair of Atom types.
      *
      * \param i        type of Atom 1
      * \param j        type of Atom 2
      * \param epsilon  LJ energy parameter
      */
      void setEpsilon(int i, int j, double epsilon);
 
      /**
      * Get LJ range for a specific pair of Atom types.
      *
      * \param i      atom type index 1
      * \param j      atom type index 2
      * \param sigma  LJ range parameter
      */
      void setSigma(int i, int j, double sigma);

      /**
      * Modify a parameter, identified by a string.
      *
      * \param name   parameter name
      * \param i      atom type index 1
      * \param j      atom type index 2
      * \param value  new value of parameter
      */
      void set(std::string name, int i, int j, double value);

      //@}
      /// \name Accessors
      //@{ 
 
      /**
      * Returns interaction energy for a single pair of particles. 
      *
      * \param rsq square of distance between particles
      * \param i   type of particle 1
      * \param j   type of particle 2
      * \return    pair interaction energy
      */
      double energy(double rsq, int i, int j) const;
   
      /**
      * Returns ratio of scalar pair interaction force to pair separation.
      *
      * Multiply this quantity by the components of the separation vector
      * to obtain the force vector. A positive value for the return value
      * represents a repulsive force between a pair of particles.
      *
      * \param rsq square of distance between particles
      * \param i type of particle 1
      * \param j type of particle 2
      * \return  force divided by distance 
      */
      double forceOverR(double rsq, int i, int j) const;
   
      //@}
      /// \name Other Accessors
      //@{

      /**
      * Get LJ interaction energy for a specific pair of Atom types.
      *
      * \param i   type of Atom 1
      * \param j   type of Atom 2
      * \return    epsilon_[i][j]
      */
      double epsilon(int i, int j) const;
 
      /**
      * Get LJ range for a specific pair of Atom types.
      *
      * \param i   atom type index 1
      * \param j   atom type index 2
      * \return    sigma_[i][j]
      */
      double sigma(int i, int j) const;
 
      /**
      * Get a parameter value, identified by a string.
      *
      * \param name   parameter name
      * \param i      atom type index 1
      * \param j      atom type index 2
      */
      double get(std::string name, int i, int j) const;

      /**
      * Get maximum of pair cutoff distance, for all atom type pairs.
      */
      double maxPairCutoff() const;
 
      /**
      * Return name string "DpdPair" for this evaluator class.
      */
      std::string className() const;
 
      //@}

   private:
   
      /// Maximum allowed value for nAtomType (# of particle types)
      static const int MaxAtomType = 2;
   
      // Parameters for different types of particle pairs
      double epsilon_[MaxAtomType][MaxAtomType];   ///< energy parameter
      double sigma_[MaxAtomType][MaxAtomType];     ///< range parameter
      double sigmaSq_[MaxAtomType][MaxAtomType];   ///< square of sigma[][].
      double ce_[MaxAtomType][MaxAtomType];        ///< energy prefactor
      double cf_[MaxAtomType][MaxAtomType];        ///< force prefactor
 
      /**
      * Maximum pair potential cutoff radius, for all monomer type pairs.
      *
      * Used in construction of a cell list or Verlet pair list.
      */
      double maxPairCutoff_;

      /// Number of possible atom types.
      int    nAtomType_; 

      /// Are all parameters and pointers initialized?
      bool  isInitialized_;

   };
  
   // inline methods 
 
   /* 
   * Calculate interaction energy for a pair, as function of squared distance.
   */
   inline double DpdPair::energy(double rsq, int i, int j) const 
   {
      double dr;
      if (rsq < sigmaSq_[i][j]) {
         dr = sqrt(rsq) - sigma_[i][j];
         return ce_[i][j]*dr*dr;
      } else {
         return 0.0;
      }
   }
   
   /* 
   * Calculate force/distance for a pair as function of squared distance.
   */
   inline double DpdPair::forceOverR(double rsq, int i, int j) const
   {
      if (rsq < sigmaSq_[i][j]) {
         return cf_[i][j]*(sigma_[i][j]/sqrt(rsq) - 1.0);
      } else {
         return 0.0;
      }
   }

}
#endif
